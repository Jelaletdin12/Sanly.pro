<script setup >
import { ref, onMounted, onUnmounted } from 'vue';
import carousel from './carousel.vue';

const activeCategory = ref('');
// const toggleDropdown = (category) => {
//   activeCategory.value = category;
// };

const toggleDropdown = (category) => {
  activeCategory.value = activeCategory.value === category ? '' : category;
};

</script>

<template>
   <RouterView />

    <div style="padding-top: 120px;"  id="team"></div>
    <div class="team-home" id="team">
        <span class="big-title">{{ $t('TEAM') }}</span>
        <span class="big-title__subtitle">{{ $t('We follow the best world trends. We can listen to our clients and hear them. We see the essence and find the bright solutions for each of our project.') }}</span>
        <div><img style="width: 100%; height: 291px;" src="../assets/3239862.jpg" alt=""></div>
        <div class="team-home__list"> <div class="team-home__item"> <div class="team-home__description" style="opacity: 1; transform: translate3d(0px, 0px, 0px);"> <div class="team-home__name"></div> <div class="team-home__subtitle"></div> </div> </div> </div>
        <div class="team-home__line" style="width: 1000px;"></div>
        <div class="team-counters">
            <div class="team-counter">
                <div class="team-counter__number">500+</div>
                <div class="team-counter__text">{{ $t('projects delivered') }}</div>
            </div>
            <div class="team-counter">
                <div class="team-counter__number">3+</div>
                <div class="team-counter__text">{{ $t('people in the team') }}</div>
            </div>
            <div class="team-counter">
                <div class="team-counter__number">200+</div>
                <div class="team-counter__text">{{ $t('Advanced projects') }}</div>
            </div>
            <div class="team-counter">
                <div class="team-counter__number">5+</div>
                <div class="team-counter__text">{{ $t('years of experience') }}</div>
            </div>
            <div class="team-counter">
                <div class="team-counter__number">5+</div>
                <div class="team-counter__text">{{ $t('TEAM') }}</div>
            </div>
            
        </div>
        
        <div>
            <div class="center-btn" @click="toggleDropdown('development')"><a class="btn">Вся команда </a></div>
            <div v-if="activeCategory === 'development'"><div class="carousel" style="padding-top: 15px;">
                <carousel />
            </div></div>
        </div>
        
    </div>

<!-- <div style="padding-top: 120px;" id="clients"></div>
    <div class="clients-home" id="clients">
        <span class="big-title">{{ $t('CLIENTS') }}</span>
        <span class="big-title__subtitle">{{ $t('We are proud of our cooperation with all domain leaders and are happy to become their digital partner!') }}</span>
        <ul class="clients-home__list">
            <li class="clients-home__item"><svg width="65px" height="58px" viewBox="0 0 65 58" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    <g id="Страницы" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
        <path d="M2.83728729,17.7859757 L2.83728729,3.30841475 L0,3.30841475 L0,0.211845306 L9.88178442,0.211845306 L9.88178442,3.30841475 L7.04449713,3.30841475 L7.04449713,17.7859757 L2.83728729,17.7859757 Z M15.2686179,12.6702831 L15.2686179,17.7862154 L11.0614081,17.7862154 L11.0614081,0.211285926 L15.2686179,0.211285926 C19.8369371,0.211285926 21.6637734,0.867359091 21.6637734,4.71669458 L21.6637734,8.28234435 C21.6637734,11.8256189 20.0293649,12.6702831 15.9179596,12.6702831 L15.2686179,12.6702831 Z M15.2686179,3.30865449 L15.2686179,9.5737137 L16.206192,9.5737137 C17.1445848,9.5737137 17.4565636,9.31559965 17.4565636,8.30631779 L17.4565636,4.52810351 C17.4565636,3.51962077 17.1445848,3.30865449 16.206192,3.30865449 L15.2686179,3.30865449 Z M26.4494132,13.4916931 L25.968753,17.7861355 L21.7599055,17.7861355 L24.4538954,0.211206014 L31.1381021,0.211206014 L33.9025125,17.7861355 L29.5994981,17.7861355 L29.1180191,13.4916931 L26.4494132,13.4916931 Z M27.8193358,2.25214495 L26.8334501,10.5349688 L28.7339822,10.5349688 L27.8193358,2.25214495 Z M39.4332984,10.089782 L39.4332984,17.7860556 L35.2260886,17.7860556 L35.2260886,0.211126103 L39.4332984,0.211126103 L39.4332984,6.99241341 L41.5974976,6.99241341 L41.5974976,0.211126103 L45.8047075,0.211126103 L45.8047075,17.7860556 L41.5974976,17.7860556 L41.5974976,10.089782 L39.4332984,10.089782 Z M53.0615303,17.9968621 C48.7102043,17.9968621 47.6276952,17.1521978 47.6276952,13.0695208 L47.6276952,4.92734121 C47.6276952,0.938959767 48.5906534,0 53.0615303,0 C57.1500081,0 57.8468425,1.1962747 57.8468425,4.92734121 L57.8468425,6.14679024 L54.0244884,6.14679024 L54.0244884,4.36396535 C54.0244884,3.37865693 53.8066765,3.14371721 52.9657258,3.14371721 C52.1239563,3.14371721 51.9560937,3.37865693 51.9560937,4.36396535 L51.9560937,13.656071 C51.9560937,14.6421786 52.1239563,14.8763192 52.9657258,14.8763192 C53.8066765,14.8763192 54.0244884,14.6421786 54.0244884,13.656071 L54.0244884,11.2387491 L57.8468425,11.2387491 L57.8468425,13.0695208 C57.8468425,17.0355271 57.0296383,17.9968621 53.0615303,17.9968621 Z M6.87655265,35.7276988 C2.71683564,35.7276988 0.840868779,34.7655647 0.840868779,31.1991159 L0.840868779,25.7075997 C0.840868779,22.1187756 2.64477755,21.2029901 6.87655265,21.2029901 L6.87655265,19.8892456 L10.9642116,19.8892456 L10.9642116,21.2029901 C15.1714214,21.2029901 16.9745113,22.1187756 16.9745113,25.7075997 L16.9745113,31.1991159 C16.9745113,34.7655647 15.0993633,35.7276988 10.9642116,35.7276988 L10.9642116,37.4641751 L6.87655265,37.4641751 L6.87655265,35.7276988 Z M4.92934654,25.5909289 L4.92934654,31.2230893 C4.92934654,32.2547464 5.26507173,32.4896861 6.20264574,32.4896861 L6.87655265,32.4896861 L6.87655265,24.3003587 L6.20264574,24.3003587 C5.26507173,24.3003587 4.92934654,24.5584727 4.92934654,25.5909289 Z M10.9642116,24.3003587 L10.9642116,32.4896861 L11.6127344,32.4896861 C12.5511272,32.4896861 12.8876713,32.231572 12.8876713,31.1991159 L12.8876713,25.5437812 C12.8876713,24.5121241 12.5511272,24.3003587 11.6127344,24.3003587 L10.9642116,24.3003587 Z M24.2136472,37.6752213 C19.7894442,37.6752213 18.754428,36.830557 18.754428,32.7478801 L18.754428,24.6057004 C18.754428,20.6404933 19.7411326,19.6775601 24.2136472,19.6775601 C28.612466,19.6775601 29.6474823,20.6404933 29.6474823,24.6057004 L29.6474823,32.7478801 C29.6474823,36.9480269 28.7090894,37.6752213 24.2136472,37.6752213 Z M23.0828265,24.0423246 L23.0828265,33.3336311 C23.0828265,34.3205378 23.3227472,34.5778527 24.2136472,34.5778527 C25.1029095,34.5778527 25.3190838,34.3205378 25.3190838,33.3336311 L25.3190838,24.0423246 C25.3190838,23.0570161 25.1029095,22.7749286 24.2136472,22.7749286 C23.3227472,22.7749286 23.0828265,23.0338418 23.0828265,24.0423246 Z M42.0297643,24.3945743 L42.0297643,27.9602241 C42.0297643,31.5042978 40.3945369,32.348962 36.2839504,32.348962 L35.6346088,32.348962 L35.6346088,37.4640952 L31.427399,37.4640952 L31.427399,19.8891657 L35.6346088,19.8891657 C40.2029279,19.8891657 42.0297643,20.5460379 42.0297643,24.3945743 Z M37.8225544,27.9841975 L37.8225544,24.2059832 C37.8225544,23.1975005 37.5105757,22.9865342 36.5721828,22.9865342 L35.6346088,22.9865342 L35.6346088,29.2515934 L36.5721828,29.2515934 C37.5105757,29.2515934 37.8225544,28.9934794 37.8225544,27.9841975 Z M9.56972376,53.4348818 L12.0942134,39.5678445 L18.0815856,39.5678445 L18.0815856,57.1419749 L14.3059055,57.1419749 L14.546645,42.2656557 L11.7576694,57.1419749 L7.11729218,57.1419749 L4.40037465,42.2656557 L4.68860701,57.1419749 L1.08242715,57.1419749 L1.08242715,39.5678445 L7.16560385,39.5678445 L9.56972376,53.4348818 Z M22.0972683,39.5676048 L28.781475,39.5676048 L31.5467042,57.1425343 L27.242871,57.1425343 L26.7622108,52.8480919 L24.093605,52.8480919 L23.6121259,57.1425343 L19.4049161,57.1425343 L22.0972683,39.5676048 Z M24.4776418,49.8913675 L26.3773551,49.8913675 L25.4627087,41.6085437 L24.4776418,49.8913675 Z M30.897772,42.6648135 L30.897772,39.567445 L40.7803753,39.567445 L40.7803753,42.6648135 L37.9422691,42.6648135 L37.9422691,57.1423745 L33.7350593,57.1423745 L33.7350593,42.6648135 L30.897772,42.6648135 Z M47.1765952,39.3560791 C51.5754141,39.3560791 52.6104303,40.3182132 52.6104303,44.2842194 L52.6104303,52.4263991 C52.6104303,56.6257468 51.6720374,57.3529412 47.1765952,57.3529412 C42.7523923,57.3529412 41.7173761,56.5082769 41.7173761,52.4263991 L41.7173761,44.2842194 C41.7173761,40.3182132 42.7040806,39.3560791 47.1765952,39.3560791 Z M48.2820318,53.0121501 L48.2820318,43.7208436 C48.2820318,42.7355352 48.0658576,42.4534477 47.1765952,42.4534477 C46.2856952,42.4534477 46.0457745,42.7115617 46.0457745,43.7208436 L46.0457745,53.0121501 C46.0457745,53.9982577 46.2856952,54.2563717 47.1765952,54.2563717 C48.0658576,54.2563717 48.2820318,53.9982577 48.2820318,53.0121501 Z M58.5975568,39.5680043 C63.165876,39.5680043 64.9935311,40.2240775 64.9935311,44.0726139 L64.9935311,47.6390628 C64.9935311,51.1823373 63.357485,52.0270016 59.2468985,52.0270016 L58.5975568,52.0270016 L58.5975568,57.1421347 L54.390347,57.1421347 L54.390347,39.5680043 L58.5975568,39.5680043 Z M60.7855025,47.6622371 L60.7855025,43.8848219 C60.7855025,42.8755401 60.4735237,42.6645738 59.5351308,42.6645738 L58.5975568,42.6645738 L58.5975568,48.929633 L59.5351308,48.929633 C60.4735237,48.929633 60.7855025,48.6715189 60.7855025,47.6622371 Z M64.0026505,22.8226358 C64.6036805,23.416378 64.8002026,24.7644845 64.8002026,24.7644845 C64.8002026,24.7644845 65,26.3483298 65,27.931376 L65,29.4161312 C65,30.9991774 64.8002026,32.5822236 64.8002026,32.5822236 C64.8002026,32.5822236 64.6036805,33.9311292 64.0026505,34.5248714 C63.2403087,35.3040082 62.3854377,35.3080038 61.9940313,35.3543525 C59.18786,35.5517338 54.9749182,35.5581267 54.9749182,35.5581267 C54.9749182,35.5581267 49.7621705,35.511778 48.1580592,35.3615445 C47.7117903,35.2792357 46.7095278,35.3040082 45.947186,34.5248714 C45.346156,33.9311292 45.1504528,32.5822236 45.1504528,32.5822236 C45.1504528,32.5822236 44.9498365,30.9991774 44.9498365,29.4161312 L44.9498365,27.931376 C44.9498365,26.3483298 45.1504528,24.7644845 45.1504528,24.7644845 C45.1504528,24.7644845 45.346156,23.416378 45.947186,22.8226358 C46.7095278,22.043499 47.5643988,22.0395034 47.9558052,21.9939539 C50.7619765,21.7957734 54.970824,21.7957734 54.970824,21.7957734 L54.9798313,21.7957734 C54.9798313,21.7957734 59.18786,21.7957734 61.9940313,21.9939539 C62.3854377,22.0395034 63.2403087,22.043499 64.0026505,22.8226358 Z M52.1851238,32.3408909 L58.9119102,28.5283147 L52.1851238,25.0114109 L52.1851238,32.3408909 Z" id="Combined-Shape" fill="#000000"></path>
    </g>
</svg></li>
<li class="clients-home__item"></li>
        </ul>
    </div> -->
<div id="review" style="padding-top: 120px;"></div>
    <div class="reviews-holder--home" >
        <span class="big-title">{{ $t('CLIENTS') }}</span>
        <span class="big-title__subtitle">{{ $t('Our clients are extremely diverse companies. We have created tailor-made solution for every business and client who worked with us.') }}</span>
        <div class="map-holder"><img width="100%" src="../assets/img/bg-map.png" alt=""></div>
    </div>
    <div style="display: block; opacity: 1; transform: translate3d(0px, 0px, 0px);">
        <h1 class="home-text-section__title" >{{ $t('WEBSITE DEVELOPMENT') }}</h1>
        <div class="home-text-section__text">
            <p>{{ $t('text') }}</p>
            <p>{{ $t('text2') }}</p>
            <p>{{ $t('text3') }}</p>
            <p>
                <ul>
                    <li style="list-style: none;">{{ $t('t1') }}</li>
                    <li  style="list-style: none;">{{ $t('t2') }}</li>
                    <li  style="list-style: none;">{{ $t('t3') }}</li>
                    <li  style="list-style: none;">{{ $t('t4') }}</li>
                    <li  style="list-style: none;">{{ $t('t5') }}</li>
                    <li  style="list-style: none;">{{ $t('t6') }}</li>
                </ul>
            </p>
            <h1>{{ $t('h1') }}</h1>
            <p>{{ $t('create') }}</p>
            <p>{{ $t('create2') }}</p>
            <p>{{ $t('create3') }}</p>
            <!-- <p>{{ $t('text1') }}</p>
            <p>{{ $t('text1') }}</p> -->
        </div>
    </div>
    
 
</template>

<style scoped>
.carousel{
   display: flex;
   justify-content: center;
}
.team-home {
    padding: 0 100px;
    /* margin-bottom: 170px; */
}
.big-title {
    display: block;
    color: #000;
    text-align: center;
    text-transform: uppercase;
    font-size: 54px;
    font-weight: 900;
    line-height: 1;
    letter-spacing: 1px;
    margin: 0 0 40px;
}
.big-title__subtitle {
    font-size: 16px;
    color: #666;
    max-width: 500px;
    margin: 0 auto 60px;
    display: block;
    text-align: center;
}
.team-home__line {
    width: 100%;
    height: 1px;
    opacity: .1;
    background-color: #000;
    margin-bottom: 40px;
}
.team-home__list {
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -ms-flex-wrap: wrap;
    flex-wrap: wrap;
    margin-bottom: 30px;
}
.team-counters {
    margin-bottom: 50px;
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-pack: justify;
    -ms-flex-pack: justify;
    justify-content: space-between;
    -ms-flex-wrap: wrap;
    flex-wrap: wrap;
}
.team-counter {
    max-width: 115px;
}
.team-counter__number {
    font-size: 40px;
    font-weight: 500;
    line-height: 1;
}
.team-counter__text {
    font-size: 12px;
    line-height: 1;
}
.center-btn {
    text-align: center;
}
.btn{
    font-size: 14px;
    font-weight: 700;
    text-decoration: none;
    color: #fff !important;
    background: #f8de15;
    letter-spacing: 1px;
    border: 1px solid #f8de15;
    border-radius: 30px;
    text-transform: uppercase;
    padding: 19px 35px 17px;
    line-height: 1;
    display: inline-block;
    cursor: pointer;
    outline: 0;
}
/* .clients-home {
    margin-bottom: 200px;
} */
.clients-home__list {
    max-width: 768px;
    margin: 0 auto 50px;
}
.clients-home__item {
    display: inline-block;
    width: 25%;
    text-indent: 0;
    margin: 0 -4px 50px;
    vertical-align: middle;
    text-align: center;
}
.clients-home__item img {
    max-width: 100px;
    height: 100%;
    width: 100%;
    max-height: 65px;
}
.reviews-holder--home {
    margin-bottom: 100px;
}
.map-holder {
    background: url(../images/bg-map.png) no-repeat 50% 0;
    width: 100%;
    /* height: 590px; */
    background-size: 100% auto;
    margin: 0 auto;
    position: relative;
}
.home-text-section__title {
    font-size: 30px;
    line-height: 32px;
    font-weight: 700;
    text-transform: uppercase;
    position: relative;
    padding-left: 60px;
    color: #000;
    margin-bottom: 25px;
}
.home-text-section__text {
    color: #333;
    font-size: 14px;
    line-height: 24px;
    height: 170px;
    margin-bottom: 25px;
    height: 100%;
}
.home-text-section__text p {
    margin: 0 0 25px;
}
.btn{
   font-size: 12px;
    font-weight: 800;
    text-decoration: none;
    color: #000;
    background: #02a352;
    letter-spacing: 1px;
    border: 1px solid #02a352;
    border-radius: 30px;
    text-transform: uppercase;
    padding: 14px 25px 12px;
    line-height: 1;
    display: inline-block;
    cursor: pointer;
    outline: 0;
}
@media screen and (max-width: 740px) {
  .team-counter {
    max-width: 115px;
    padding: 5px 20px;
}
}
@media screen and (max-width: 480px){
    .team-home{
        padding: 0 15px;
    }
    .big-title{
        font-size: 40px;
    }
    .team-home__line{
        width: 100% !important;
    }
    .team-counter{
    padding-bottom: 15px;
  }
    .reviews-holder--home{
        padding: 0 15px;
    }
    .home-text-section__text{
        padding: 0 15px;
    }
}
</style>
